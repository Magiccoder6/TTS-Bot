from gtts import gTTS
from playsound import playsound
import os

def speak(message):
    engine = gTTS(message)
    engine.save("voice.mp3")
    playsound('voice.mp3')
    os.remove('voice.mp3')
