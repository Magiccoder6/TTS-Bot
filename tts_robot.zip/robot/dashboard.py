import tkinter as tk
from PIL import Image, ImageTk
from itertools import count, cycle
import ttsm
import threading
from tkinter import filedialog




root = tk.Tk()
root.geometry("800x700")
root.title("LIZ TTS Program")

background_image=tk.PhotoImage(file="images/background.png")
background_label = tk.Label(root, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

heading = tk.Label(root,fg="white",bg="black",text="LIZ TTS MENU",font = "Times 16 bold italic")
heading.pack()


def menu():
    robot = ImageLabel(root)
    robot.pack()
    robot.load('images/robot2.gif')

    label = tk.Label(root,text="Enter Text below: ")
    label.pack()

    global textarea
    textarea = tk.Text(root,height=10,width=50,wrap=tk.WORD)
    textarea.pack()
    
    convert_button = tk.Button(root,bg="pink",text="convert to speech",font = "Times 15 bold italic",command=lambda:speak(textarea.get("1.0","end")))
    convert_button.pack()

    upload_button = tk.Button(root,bg="blue",fg="white",text="upload text file",font = "Times 15 bold italic",command=browseFiles)
    upload_button.pack()




    return


class ImageLabel(tk.Label):
    """
    A Label that displays images, and plays them if they are gifs
    :im: A PIL Image instance or a string filename
    """
    def load(self, im):
        if isinstance(im, str):
            im = Image.open(im)
        frames = []
 
        try:
            for i in count(1):
                frames.append(ImageTk.PhotoImage(im.copy()))
                im.seek(i)
        except EOFError:
            pass
        self.frames = cycle(frames)
 
        try:
            self.delay = im.info['duration']
        except:
            self.delay = 100
 
        if len(frames) == 1:
            self.config(image=next(self.frames))
        else:
            self.next_frame()
 
    def unload(self):
        self.config(image=None)
        self.frames = None
 
    def next_frame(self):
        if self.frames:
            self.config(image=next(self.frames))
            self.after(self.delay, self.next_frame)
def speak(text):
    x=threading.Thread(target=ttsm.speak,args=(text,))
    x.start()
    
def browseFiles():
    filename = filedialog.askopenfilename(initialdir = "/",title = "Select a File",filetypes = (("Text files","*.txt*"),("doc files","*.doc*")))
    
    try:
        f = open(filename, "r")
        speak(f.read())
        f.close()
    except:
        speak("No file was selected")

def main():
    menu()

    #robot intro
    x=threading.Thread(target=ttsm.speak,args=("Hey my name is liz, you can input any text below then i will convert it for you",))
    x.start()
    
    
    root.mainloop()
    
    return


if __name__=="__main__":
    main()
