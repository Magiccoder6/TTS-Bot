REQUIREMENTS


Install the modules below with pip

(1) tk (tkinter - python framework for GUI)
(2) pyttsx3 - API Interface for text to speach
(3) playsound - Module for playing sound
